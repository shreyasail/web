<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="dashboard.php"><i class="fa fa-dashboard fa-fw nav_icon"></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-indent nav_icon"></i>  Receipt<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="add-receipt.php">Add Receipt</a>
                                </li>
                                <li>
                                    <a href="manage-receipt.php">Manage Receipt</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                     
                        <li>
                            <a href="search-receipt.php"><i class="fa fa-search"></i>   Search</a>
                        </li>
                       
              
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>